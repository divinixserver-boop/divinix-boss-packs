# BetonQuest 3.2 — syntax that actually works

A reference for the version you are actually running. Most of what you will
find by searching is written for 2.x and will fail silently or loudly.

Everything below was verified against **BetonQuest 3.2.0** on a running server.

---

## The seven mistakes that cost the most time

**1. Items need the `simple` prefix.**

```yaml
items:
  key: 'simple TRIPWIRE_HOOK'      # correct
  key: 'TRIPWIRE_HOOK'             # "'TRIPWIRE_HOOK' is not loaded for type 'items'"
```

**2. Quotes wrap the whole argument, key included.**

```yaml
  sword: 'simple IRON_SWORD "name:<!i><gold>Blade of the Watch"'   # correct
  sword: 'simple IRON_SWORD name:"<!i><gold>Blade of the Watch"'   # "Unknown argument 'of'"
```

**3. `objective` takes add / remove / complete. Nothing else.**

```yaml
  start: 'objective add my_objective'       # correct
  stop: 'objective remove my_objective'     # correct
  stop: 'objective cancel my_objective'     # "Invalid action: cancel"
```

**4. Pointers cross over.** A `player_options` entry points at an
`NPC_options` entry, and vice versa. Pointing at your own kind throws
`points to X NPC option, but it does not exist`.

**5. Cross-package references use `>`, not a dot.**

```
/bq action Steve blueprint_fetch>quest_start    # correct
/bq action Steve blueprint_fetch.quest_start    # "has no package specified!"
```

The same applies inside your files whenever you reference something in another
package: `otherpackage>some_action`.

**6. Translated `notify` actions go on ONE line, not as a YAML map.**

```yaml
# correct - the player sees only their own language
done: 'notify {en-US} Quest complete! {es-ES} Misión completada! category:info'

# WRONG - BetonQuest fires both, the player sees the message twice
done:
  en-US: 'notify Quest complete! category:info'
  es-ES: 'notify Misión completada! category:info'
```

The YAML map form IS correct for journal entries, conversations and quest
cancelers. It is only actions that need the one-line form.

Also: any `:` inside the message text must be escaped as `\:`. Arguments like
`category:info` are not escaped.

**7. Never hand-edit `package.version`.**
Set it to the current value (`3.2.0-QUEST-2`) and leave it. Put an older
version there and the migrator rewrites your files on load — among other
things it prefixes every item with `simple`, turning `simple DIAMOND` into
`simple simple DIAMOND`.

---

## Package layout

```yaml
# package.yml
package:
  version: 3.2.0-QUEST-2

npcs:
  my_npc: citizens 0          # or: fancyNpcs name | znpcsplus 0 | mythicmobs id

npc_conversations:
  my_npc: my_conversation     # npc id -> conversation name

constants:
  amount: '10'                # read anywhere as %constant.amount%

items:
  my_item: 'simple DIAMOND'
```

Files in a package: `package.yml`, `conditions.yml`, `events.yml` (holds the
`actions:` section), `objectives.yml`, `journal.yml`, `conversations/*.yml`.

---

## Objectives (objectives.yml)

| Objective | Syntax |
|-----------|--------|
| Kill mobs | `mobkill <types> <amount> [name:] [marked:] [notify:N]` |
| Break/place blocks | `block <block> <amount> [notify]` — negative amount = break |
| Reach a place | `location <x;y;z;world> <range> [entry] [exit]` |
| Pick up items | `pickup <item> [amount:N]` |
| Craft | `craft <item> [amount]` |
| Click an NPC | `npcinteract <npc> [cancel] [interaction:left/right/any]` |
| Wait (cooldown) | `delay <minutes> [seconds/ticks] [interval:N]` |
| Questline position | `stage <s1,s2,s3> [preventCompletion]` |
| First join | `login auto-once` |
| Take damage | `damage <amount> [type] [min]` |

Shared arguments: `conditions:`, `actions:` (fires on completion),
`persistent` (survives restarts and repeats), `auto-once` (handed to every
player once).

```yaml
objectives:
  hunt: 'mobkill ZOMBIE,HUSK 15 notify:5 actions:reward'
  boss: 'mobkill ZOMBIE 1 marked:questboss actions:boss_won'
  cooldown: 'delay 1440 actions:daily_reset persistent'   # 1440 min = 24h
```

`delay` counts **minutes** by default. There is no `hours` unit.

---

## Actions (events.yml, under `actions:`)

| Action | Syntax |
|--------|--------|
| Give items | `give <item>[:amount],<item2>` |
| Take items | `take <item>:<amount>` |
| Tags | `tag add/delete <tag>` |
| Points | `point <category> <amount> action:add/subtract/set/multiply` |
| Experience | `experience <n> action:addExperience/addLevel/setLevel` |
| Money (Vault) | `money +100` — the sign is required |
| Journal | `journal add/delete <entry>` |
| Objectives | `objective add/remove/complete <objective>` |
| Run several | `folder a,b,c [delay:N] [period:N] [unit:seconds]` |
| Message | `notify <text> [category:info] [io:chat/actionbar/title]` |
| Message everyone | `notifyall <text>` |
| Teleport | `teleport <x;y;z;world>` |
| Spawn a mob | `spawn <loc> <type> <amount> [name:] [marked:] [h: c: l: b: m: o:] [drops:]` |
| Questline step | `stage <objective> set/increase/decrease [stage or amount]` |
| Conditional | `if <condition> <action1> else <action2>` |
| Console command | `command <cmd>` — `sudo` runs it as the player |
| Heal | `heal <amount>` |
| Give the journal | `givejournal` |

```yaml
actions:
  reward: 'folder pay,thank,clean'
  pay: 'give diamond:3'
  slow_intro: 'folder line1,line2,line3 delay:3 period:2'
  summon: 'spawn 100;70;200;world ZOMBIE 1 name:Warden marked:boss h:helmet m:sword'
```

---

## Conditions (conditions.yml)

| Condition | Syntax |
|-----------|--------|
| Has tag | `tag <tag>` |
| Has items | `item <item>:<amount>` |
| Points at least | `point <category> <amount>` |
| Has any points | `haspoint <category>` |
| Questline position | `stage <objective> <comparator> <stage>` — `<  <=  =  !=  >=  >` |
| Objective active | `objective <objective>` |
| Permission | `permission <node>` |
| In an area | `location <x;y;z;world> <radius>` |
| Holding | `hand <item> [offhand]` |
| Time of day | `time <from-to> [world]` |
| Random chance | `random <n>-<total>` |
| Combine | `and <c1,c2>` / `or <c1,c2>` |

Prefix any condition with `!` to invert it: `conditions: 'is_active,!is_done'`.

---

## Conversations

```yaml
conversations:
  my_conversation:
    quester:
      en-US: 'Farmer'
      es-ES: 'Granjero'
    first: 'ready,in_progress,intro'     # first option whose conditions pass
    NPC_options:
      intro:
        conditions: '!is_active'
        text:
          en-US: 'Bring me ten.'
          es-ES: 'Tráeme diez.'
        pointers: 'accept,decline'       # -> player_options
    player_options:
      accept:
        text:
          en-US: 'Fine.'
        actions: 'quest_start'
        pointers: 'thanks'               # -> NPC_options
```

Order matters in `first:` — put the most specific state first and the
fallback last, because the NPC takes the first option that passes.

---

## Placeholders worth knowing

| Placeholder | Gives you |
|-------------|-----------|
| `%player%` | The player's name |
| `%constant.x%` | A constant from `package.yml` |
| `%objective.<id>.left%` | How many are left on a counter |
| `%objective.<id>.amount%` | How many are done |
| `%objective.<id>.current%` | The player's current stage name |
| `%point.<category>.amount%` | Points in a category |

---

## Admin commands

```
/bq reload                                  reload everything
/bq condition <player> <package>><id>       test a condition
/bq action <player> <package>><id>          fire an action
/bq objective <player> list                 what's active
/bq tag <player> list                       what tags they carry
/bq point <player> list                     their points
/bq location                                prints the location under you
/cancelquest                                (player) abandon a quest
/journal  (alias /j)                        (player) open the journal
/questlang <lang>                           (player) switch language
```

---

## Text formatting

3.x parses **MiniMessage** as well as legacy `&` codes. Item names are italic
by default — prefix `<!i>` to turn that off:

```yaml
  sword: 'simple IRON_SWORD "name:<!i><gold>Blade of the Watch"'
```

Lore lines are separated by `;` inside one `lore:` argument.
